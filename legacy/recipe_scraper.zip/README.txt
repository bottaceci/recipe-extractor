To start the StreamLit App, type:
	streamlit run app.py
in the terminal window.

To access the necessary python packages, you must be in the Wenv environment.